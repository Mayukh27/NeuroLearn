"use client"

import { useEffect, useState, useCallback, useRef, Suspense } from "react"
import { useRouter, useSearchParams } from "next/navigation"
import { motion, AnimatePresence } from "framer-motion"
import {
  ArrowLeft,
  BookOpen,
  ClipboardCheck,
  Sparkles,
  AlertCircle,
  Link2,
} from "lucide-react"

import VideoPlayer from "@/components/VideoPlayer"
import CameraFeed, { type AttentionSnapshotResponse } from "@/components/CameraFeed"
import AttentionPanel from "@/components/AttentionPanel"
import TranscriptionPanel from "@/components/TranscriptionPanel"
import VideoLinkSelector from "@/components/VideoLinkSelector"
import {
  fetchCourseById,
  fetchCourses,
  completeStudyVideo,
  startStudySession,
  type Course,
  type VideoLink,
  type StudySession,
} from "@/lib/api"

export default function VideoPage() {
  return (
    <Suspense fallback={
      <div className="flex items-center justify-center h-[70vh]">
        <div className="w-10 h-10 border-3 border-violet-500 border-t-transparent rounded-full animate-spin" />
      </div>
    }>
      <VideoContent />
    </Suspense>
  )
}

function newWebcamSessionId(): string {
  if (typeof crypto !== "undefined" && "randomUUID" in crypto) {
    return `webcam_${crypto.randomUUID()}`
  }
  return `webcam_${Date.now()}_${Math.random().toString(16).slice(2)}`
}

function VideoContent() {
  const router = useRouter()
  const searchParams = useSearchParams()
  const courseIdParam = searchParams.get("course")
  const videoIdParam = searchParams.get("video")
  const studySessionParam = searchParams.get("studySession")

  const [course, setCourse] = useState<Course | null>(null)
  const [selectedVideo, setSelectedVideo] = useState<VideoLink | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  const [isPlaying, setIsPlaying] = useState(false)
  const [currentTime, setCurrentTime] = useState(0)
  const [videoDuration, setVideoDuration] = useState(0)
  const [videoEnded, setVideoEnded] = useState(false)
  const [customUrl, setCustomUrl] = useState("")
  const [showCustomInput, setShowCustomInput] = useState(false)
  const [webcamSessionId, setWebcamSessionId] = useState(() => newWebcamSessionId())
  const [studySession, setStudySession] = useState<StudySession | null>(null)
  const [behavioralCueGranted, setBehavioralCueGranted] = useState<boolean | null>(null)
  const [completedVideoTranscripts, setCompletedVideoTranscripts] = useState<Record<string, string>>({})
  const [isPreparingAssessment, setIsPreparingAssessment] = useState(false)

  // Behavioral Cue state
  const [latestAttention, setLatestAttention] = useState<AttentionSnapshotResponse | null>(null)
  const [attentionHistory, setAttentionHistory] = useState<number[]>([])
  const [sessionAvgAttention, setSessionAvgAttention] = useState(0)

  // ── FIX 1: ref-based session ID ──────────────────────────────────────────
  // handleVideoEnd previously read studySession?.studySessionId directly from
  // its closure (via the dependency array). This meant that if the session
  // hadn't loaded yet when the video ended, the call was silently skipped
  // (no network request, no console error visible to the user). Using a ref
  // ensures handleVideoEnd always sees the latest session ID without needing
  // studySession in its deps — and without re-registering VideoPlayer's
  // YouTube message listener every time the session changes.
  const studySessionIdRef = useRef<string | null>(null)
  useEffect(() => {
    studySessionIdRef.current = studySession?.studySessionId ?? null
  }, [studySession?.studySessionId])

  // ── FIX 2: pending completion queue ──────────────────────────────────────
  // If a video ends before the study session is ready (race condition on first
  // load, or a brief startStudySession failure that resolves on retry), the
  // completion is queued here and flushed the moment the session arrives.
  // This decouples video-completion persistence from camera/attention state —
  // the queue and the flush are purely about the study session becoming ready,
  // not about any behavioral signal being present.
  const pendingCompletions = useRef<{ videoId: string; transcriptText: string }[]>([])

  useEffect(() => {
    const sessionId = studySession?.studySessionId
    if (!sessionId || !pendingCompletions.current.length) return
    const toFlush = pendingCompletions.current.splice(0)  // drain atomically
    Promise.all(
      toFlush.map(({ videoId, transcriptText }) =>
        completeStudyVideo(sessionId, videoId, transcriptText)
          .catch((err) =>
            console.error("[VideoPage] Failed to flush queued completion for", videoId, err)
          )
      )
    )
  }, [studySession?.studySessionId])

  // ── FIX 3: one session per course, not per video ─────────────────────────
  // The original effect had [course?.id, selectedVideo?.id, studySessionParam]
  // as dependencies. When the student selected Video 2, selectedVideo?.id
  // changed, the effect re-ran, and startStudySession was called again —
  // creating a new session. Video 1's completion belonged to session A;
  // Video 2's to session B. Assessment generation for session B saw only
  // Video 2, defeating the multi-video requirement entirely.
  //
  // Fix: track which course ID has already had a session created and skip
  // subsequent triggers from video changes. The effect still runs when
  // course?.id changes (different course → correct to start fresh) and when
  // studySessionParam appears/disappears.
  const sessionCreatedForCourseRef = useRef<string | null>(null)

  const effectiveUrl = selectedVideo?.url || customUrl || ""
  const effectiveTitle = selectedVideo?.title || (customUrl ? "Custom Video" : "Select a video")
  const effectiveBehavioralCue = behavioralCueGranted === false || attentionHistory.length === 0
    ? 50
    : sessionAvgAttention

  // Load course
  useEffect(() => {
    async function load() {
      setIsLoading(true)
      try {
        if (courseIdParam) {
          const c = await fetchCourseById(courseIdParam)
          if (c) {
            setCourse(c)
            const vids = c.videoLinks || []
            const target = videoIdParam
              ? vids.find((v) => v.id === videoIdParam)
              : vids.find((v) => !v.completed) || vids[0]
            if (target) setSelectedVideo(target)
          }
        } else {
          const courses = await fetchCourses()
          if (courses.length > 0) {
            setCourse(courses[0])
            const vids = courses[0].videoLinks || []
            const first = vids.find((v) => !v.completed) || vids[0]
            if (first) setSelectedVideo(first)
          }
        }
      } catch (err) {
        console.error("Failed to load course:", err)
      } finally {
        setIsLoading(false)
      }
    }
    load()
  }, [courseIdParam, videoIdParam])

  useEffect(() => {
    if (!course || !selectedVideo) return
    if (studySessionParam) {
      setStudySession({
        studySessionId: studySessionParam,
        participantId: "",
        condition: "MIXED",
        sequenceOrder: "MCRF_THEN_LEGACY",
        completionStatus: "started",
        experimentVersion: "full-study-v1",
      })
      return
    }

    // FIX 3 guard: only start a session once per course, not once per video.
    // If we already have a session for this course, do nothing — the existing
    // session accumulates completions for every video the student watches.
    if (sessionCreatedForCourseRef.current === course.id) return
    sessionCreatedForCourseRef.current = course.id

    let cancelled = false
    ;(async () => {
      try {
        const session = await startStudySession(course.id, undefined, course.id)
        if (!cancelled) setStudySession(session)
      } catch (err) {
        console.error("Failed to start study session:", err)
        // Allow retry on the next course load by clearing the guard.
        sessionCreatedForCourseRef.current = null
        if (!cancelled) setStudySession(null)
      }
    })()
    return () => {
      cancelled = true
    }
  }, [course?.id, selectedVideo?.id, studySessionParam])

  const handleTimeUpdate = useCallback((ct: number, dur: number) => {
    setCurrentTime(ct)
    setVideoDuration(dur)
  }, [])

  const handlePlayStateChange = useCallback((playing: boolean) => {
    setIsPlaying(playing)
    if (playing) setVideoEnded(false)
  }, [])

  const handleVideoEnd = useCallback(() => {
    setVideoEnded(true)
    setIsPlaying(false)
    const completedVideoId = selectedVideo?.id || (customUrl ? "custom" : null)
    if (!completedVideoId) return

    const transcriptText = typeof window !== "undefined" && (window as any).__transcriptText
      ? (window as any).__transcriptText()
      : ""

    setCompletedVideoTranscripts((prev) => ({
      ...prev,
      [completedVideoId]: transcriptText,
    }))

    // FIX 1+2 combined: read session ID from ref (always current, no stale
    // closure), and queue if the session isn't ready yet. Camera state is
    // NOT checked here — video completion is independent of whether the
    // webcam is on, off, or erroring. The pending-completion flush effect
    // above handles the queued case when the session eventually arrives.
    const sessionId = studySessionIdRef.current
    if (sessionId) {
      void completeStudyVideo(sessionId, completedVideoId, transcriptText)
        .catch((err) => console.error("Failed to record completed video:", err))
    } else {
      // Session not ready (race condition or startStudySession still in-flight).
      // Queue the completion — the flush effect will send it once the session ID lands.
      pendingCompletions.current.push({ videoId: completedVideoId, transcriptText })
      console.warn(
        "[VideoPage] No study session yet — completion queued for video:",
        completedVideoId
      )
    }
    // NOTE: studySession?.studySessionId is intentionally NOT in the dep
    // array — we read via ref instead. This keeps handleVideoEnd stable
    // across video changes so VideoPlayer doesn't re-register its YouTube
    // message listener on every session update.
  }, [customUrl, selectedVideo?.id])

  // FIXED: Use functional updates — no stale closure on attentionHistory
  const handleAttentionUpdate = useCallback((snapshot: AttentionSnapshotResponse) => {
    setLatestAttention(snapshot)
    setAttentionHistory((prev) => {
      const next = [...prev, snapshot.score].slice(-60)
      // Compute avg inside the same update
      const avg = next.length > 0
        ? Math.round(next.reduce((s, v) => s + v, 0) / next.length * 10) / 10
        : 0
      setSessionAvgAttention(avg)
      return next
    })
  }, [])

  const handleSelectVideo = useCallback((video: VideoLink) => {
    setSelectedVideo(video)
    setIsPlaying(false)
    setCurrentTime(0)
    setVideoEnded(false)
    setAttentionHistory([])
    setLatestAttention(null)
    setSessionAvgAttention(0)
    setBehavioralCueGranted(null)
    setWebcamSessionId(newWebcamSessionId())
    setCustomUrl("")
    setShowCustomInput(false)
  }, [])

  const handleCustomUrlSubmit = () => {
    if (!customUrl.trim()) return
    setSelectedVideo(null)
    setIsPlaying(false)
    setCurrentTime(0)
    setVideoEnded(false)
    setAttentionHistory([])
    setLatestAttention(null)
    setSessionAvgAttention(0)
    setBehavioralCueGranted(null)
    setWebcamSessionId(newWebcamSessionId())
    setShowCustomInput(false)
  }

  const goToAssessment = async () => {
    if (isPreparingAssessment) return
    const currentCompletedVideoId = selectedVideo?.id || (customUrl ? "custom" : null)
    const currentTranscriptText = typeof window !== "undefined" && (window as any).__transcriptText
      ? (window as any).__transcriptText()
      : ""
    setIsPreparingAssessment(true)
    try {
      if (!studySession?.studySessionId) {
        throw new Error("Study session is not ready yet.")
      }

      const transcriptsToPersist = {
        ...completedVideoTranscripts,
        ...(currentCompletedVideoId ? { [currentCompletedVideoId]: currentTranscriptText } : {}),
      }
      if (Object.keys(transcriptsToPersist).length === 0) {
        throw new Error("Complete a video before starting the assessment.")
      }

      // The backend derives the assessment context exclusively from these
      // completion records.  Replaying all entries is safe and preserves the
      // original completion order on the server.
      await Promise.all(
        Object.entries(transcriptsToPersist).map(([videoId, transcriptText]) =>
          completeStudyVideo(studySession.studySessionId, videoId, transcriptText)
        )
      )
    // Build behavioral_cue summary to thread through to report card
    const attentionSummary = {
      avgScore: Math.round(effectiveBehavioralCue * 10) / 10,
      scoreHistory: attentionHistory.slice(-40),
      totalSnapshots: attentionHistory.length,
      attentivePercent: Math.round((attentionHistory.filter(s => s >= 65).length / Math.max(attentionHistory.length, 1)) * 100),
      inattentivePercent: Math.round((attentionHistory.filter(s => s >= 30 && s < 65).length / Math.max(attentionHistory.length, 1)) * 100),
      unfocusedPercent: Math.round((attentionHistory.filter(s => s < 30).length / Math.max(attentionHistory.length, 1)) * 100),
      avgEyeContact: behavioralCueGranted === false ? 0.5 : latestAttention?.modelResponse?.eyeContact ?? 0.8,
      avgBlinkRate: behavioralCueGranted === false ? 0 : latestAttention?.modelResponse?.blinkRate ?? 16,
    }
    const params = new URLSearchParams({
      videos: Object.keys(transcriptsToPersist).join(","),
      course: course?.id || "custom",
      video: selectedVideo?.id || "custom",
      studySession: studySession.studySessionId,
      courseTitle: course?.title || "Custom Video",
      videoTitle: selectedVideo?.title || "Video Session",
      behavioral_cue: Math.round(effectiveBehavioralCue).toString(),
      attentionData: JSON.stringify(attentionSummary),
      transcript: Object.entries(transcriptsToPersist)
        .map(([id, text]) => `[Video ${id}]\n${text}`)
        .join("\n\n"),
    })
    router.push(`/assessment?${params.toString()}`)
    } catch (err) {
      console.error("Assessment preparation failed:", err)
    } finally {
      setIsPreparingAssessment(false)
    }
  }

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-[70vh]">
        <motion.div animate={{ rotate: 360 }} transition={{ duration: 1.5, repeat: Infinity, ease: "linear" }} className="w-10 h-10 border-3 border-violet-500 border-t-transparent rounded-full" />
      </div>
    )
  }

  return (
    <div className="p-4 md:p-6 max-w-[1500px] mx-auto">
      {/* Header */}
      <motion.div initial={{ opacity: 0, y: -15 }} animate={{ opacity: 1, y: 0 }} className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-3">
          <motion.button whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }} onClick={() => router.push("/dashboard")}
            className="w-9 h-9 rounded-xl bg-[var(--bg-elevated)] border border-[var(--border-subtle)] flex items-center justify-center text-[var(--text-muted)] hover:text-[var(--text-primary)] hover:border-[var(--border-default)] transition-all">
            <ArrowLeft size={16} />
          </motion.button>
          <div>
            <h1 className="text-xl font-bold text-[var(--text-primary)]">Video Learning</h1>
            <p className="text-xs text-[var(--text-muted)]">AI-powered behavioral-cue monitoring &amp; live transcription</p>
          </div>
        </div>
        <motion.button whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }} onClick={() => setShowCustomInput(!showCustomInput)}
          className="flex items-center gap-2 px-3 py-2 rounded-xl bg-[var(--bg-elevated)] border border-[var(--border-subtle)] text-xs font-medium text-[var(--text-secondary)] hover:border-violet-500/30 hover:text-violet-400 transition-all">
          <Link2 size={14} /> Play Custom URL
        </motion.button>
      </motion.div>

      {/* Custom URL input */}
      <AnimatePresence>
        {showCustomInput && (
          <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: "auto", opacity: 1 }} exit={{ height: 0, opacity: 0 }} className="mb-6 overflow-hidden">
            <div className="flex gap-3 p-4 rounded-2xl bg-[var(--bg-card)] border border-[var(--border-subtle)]">
              <input type="text" value={customUrl} onChange={(e) => setCustomUrl(e.target.value)}
                placeholder="Paste any video URL — MP4 link, YouTube, etc."
                className="flex-1 px-4 py-2.5 text-sm rounded-xl bg-[var(--bg-elevated)] border border-[var(--border-subtle)] text-[var(--text-primary)] placeholder:text-[var(--text-muted)] focus:outline-none focus:border-violet-500/50 focus:ring-1 focus:ring-violet-500/20 transition-all"
                onKeyDown={(e) => e.key === "Enter" && handleCustomUrlSubmit()} />
              <motion.button whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }} onClick={handleCustomUrlSubmit} disabled={!customUrl.trim()}
                className="px-5 py-2.5 text-sm font-semibold rounded-xl bg-gradient-to-r from-violet-500 to-purple-600 text-white hover:shadow-lg hover:shadow-violet-500/20 transition-all disabled:opacity-40 disabled:cursor-not-allowed">
                Play
              </motion.button>
            </div>
            <p className="text-[10px] text-[var(--text-muted)] mt-2 px-1">Supports: Direct .mp4/.webm links, YouTube URLs, and embeddable video pages.</p>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Main 3-column layout */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
        {/* Left: Video list */}
        <div className="lg:col-span-3 order-2 lg:order-1">
          {course && (
            <VideoLinkSelector videos={course.videoLinks || []} activeVideoId={selectedVideo?.id || null} onSelect={handleSelectVideo} courseTitle={course.title} />
          )}
        </div>

        {/* Center: Video player */}
        <div className="lg:col-span-6 space-y-5 order-1 lg:order-2">
          {effectiveUrl ? (
            <VideoPlayer videoUrl={effectiveUrl} title={effectiveTitle} onTimeUpdate={handleTimeUpdate} onPlayStateChange={handlePlayStateChange} onVideoEnd={handleVideoEnd} />
          ) : (
            <div className="rounded-2xl bg-[var(--bg-card)] border border-[var(--border-subtle)] aspect-video flex flex-col items-center justify-center gap-3">
              <BookOpen size={32} className="text-[var(--text-muted)]" />
              <p className="text-sm text-[var(--text-muted)]">Select a video from the list or paste a URL</p>
            </div>
          )}

          {/* Video ended → Assessment CTA */}
          <AnimatePresence>
            {videoEnded && (
              <motion.div initial={{ opacity: 0, y: 20, scale: 0.95 }} animate={{ opacity: 1, y: 0, scale: 1 }} exit={{ opacity: 0, y: -10 }}
                className="rounded-2xl p-5 border border-violet-500/30 bg-gradient-to-br from-violet-500/10 to-purple-500/5">
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 rounded-xl bg-violet-500/20 flex items-center justify-center shrink-0">
                    <Sparkles size={24} className="text-violet-400" />
                  </div>
                  <div className="flex-1">
                    <h3 className="text-base font-bold text-[var(--text-primary)] mb-1">Ready for Assessment!</h3>
                    <p className="text-xs text-[var(--text-muted)] mb-3">
                      Your average behavioral-cue score was{" "}
                      <span className="font-bold text-violet-400">{Math.round(effectiveBehavioralCue)}%</span>.
                      Based on this and the video content, we&apos;ll generate a personalized quiz.
                    </p>
                    <div className="flex items-center gap-3">
                      <motion.button whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }} onClick={goToAssessment} disabled={isPreparingAssessment}
                        className="px-5 py-2.5 text-sm font-semibold rounded-xl bg-gradient-to-r from-violet-500 to-purple-600 text-white hover:shadow-lg hover:shadow-violet-500/20 transition-all flex items-center gap-2 disabled:opacity-60">
                        <ClipboardCheck size={16} /> {isPreparingAssessment ? "Preparing…" : "Take Assessment"}
                      </motion.button>
                      <button onClick={() => setVideoEnded(false)}
                        className="px-4 py-2.5 text-sm font-medium rounded-xl bg-[var(--bg-elevated)] text-[var(--text-secondary)] border border-[var(--border-subtle)] hover:border-[var(--border-default)] transition-all">
                        Rewatch
                      </button>
                    </div>
                  </div>
                </div>
                <div className="grid grid-cols-3 gap-3 mt-4 pt-4 border-t border-violet-500/15">
                  <div className="text-center">
                    <p className="text-lg font-bold text-[var(--text-primary)]">{Math.round(effectiveBehavioralCue)}%</p>
                    <p className="text-[10px] text-[var(--text-muted)]">Avg Behavioral Cue</p>
                  </div>
                  <div className="text-center">
                    <p className="text-lg font-bold text-[var(--text-primary)]">{attentionHistory.length}</p>
                    <p className="text-[10px] text-[var(--text-muted)]">Snapshots</p>
                  </div>
                  <div className="text-center">
                    <p className="text-lg font-bold text-[var(--text-primary)]">{Math.floor(videoDuration / 60)}m {Math.floor(videoDuration % 60)}s</p>
                    <p className="text-[10px] text-[var(--text-muted)]">Duration</p>
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          {/* Inline behavioral_cue alert during playback */}
          <AnimatePresence>
            {isPlaying && latestAttention && latestAttention.state !== "attentive" && (
              <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }}
                className={`rounded-xl p-3 flex items-center gap-3 border ${
                  latestAttention.state === "inattentive" ? "bg-amber-500/8 border-amber-500/20" : "bg-red-500/8 border-red-500/20"
                }`}>
                <AlertCircle size={18} className={latestAttention.state === "inattentive" ? "text-amber-400" : "text-red-400"} />
                <p className="text-xs text-[var(--text-secondary)]">{latestAttention.message}</p>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* Right: Camera + Behavioral Cue + Transcription */}
        <div className="lg:col-span-3 space-y-4 order-3">
          <CameraFeed
            isVideoPlaying={isPlaying}
            videoId={selectedVideo?.id || "custom"}
            studentId="student_001"
            sessionId={webcamSessionId}
            studySessionId={studySession?.studySessionId}
            onConsentChange={(granted) => {
              setBehavioralCueGranted(granted)
              if (!granted) {
                setLatestAttention(null)
                setAttentionHistory([])
                setSessionAvgAttention(0)
              }
            }}
            onAttentionUpdate={handleAttentionUpdate}
          />
          <AttentionPanel
            latestSnapshot={latestAttention}
            sessionAverage={sessionAvgAttention}
            scoreHistory={attentionHistory}
          />
          <TranscriptionPanel
            videoId={selectedVideo?.id || "custom"}
            currentTime={currentTime}
            isPlaying={isPlaying}
          />
        </div>
      </div>
    </div>
  )
}
